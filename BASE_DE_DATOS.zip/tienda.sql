-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 30-05-2017 a las 11:41:57
-- Versión del servidor: 10.1.21-MariaDB
-- Versión de PHP: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tienda`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administrador`
--

CREATE TABLE `administrador` (
  `id_administrador` int(11) NOT NULL,
  `administrador` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `celular` int(30) NOT NULL,
  `nombre` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `administrador`
--

INSERT INTO `administrador` (`id_administrador`, `administrador`, `email`, `password`, `celular`, `nombre`) VALUES
(11, 'sebastian', 'juan508sebastian@gmail.com', '1234', 5455645, 'julio de la montaña'),
(12, 'pedro', 'pedro@gmail.com', '12345', 30114585, 'pedro leal');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id_categorias` int(15) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id_categorias`, `nombre`) VALUES
(1, 'electro fiesta'),
(2, 'baños');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id_producto` int(250) NOT NULL,
  `nombre` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `precio` decimal(50,0) NOT NULL,
  `caracteristicas` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `marca` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'no se a registrado ',
  `descripcion` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `imagen` text COLLATE utf8_unicode_ci NOT NULL,
  `id_categorias` int(100) NOT NULL DEFAULT '1',
  `estado` int(1) NOT NULL DEFAULT '1',
  `cantidad` bigint(20) NOT NULL,
  `fecha` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `id_dueno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=COMPACT;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_producto`, `nombre`, `precio`, `caracteristicas`, `marca`, `descripcion`, `imagen`, `id_categorias`, `estado`, `cantidad`, `fecha`, `id_dueno`) VALUES
(1, 'nevera', '20000', 'carcaterisitrcas', 'no se a registrado ', 'sdjkbhjae', 'nevera.png', 1, 1, 5, '18/052017', 0),
(3, 'nevera', '20000', 'carcaterisitrcas', 'no se a registrado ', 'sdjkbhjae', 'nevera.png', 1, 1, 5, '1/08/2016', 0),
(4, 'televisor', '212000', 'caracterisitcas', 'no se a registrado ', 'djejnva', 'televisor.png', 1, 1, 3, '6/01/2017', 0),
(5, 'estarf', '50000', 'es blanco\r\n3000000 caballos de fuerza', 'no se a registrado ', 'modelo ker315646\r\n153456454\r\n\r\nfgfxbgdg', 'extractor.PNG', 1, 1, 0, '', 18),
(8, 'prueba', '200000', 'jhasdvfhjvhjv\r\nsadlkfnkajsbvj\r\nasdklfbvksbvjkl\r\najsdkjvbajsv\r\nasdijghbvkjz<v\r\nsdjbvjk<znv\r\nkijsdbvgjklnzalñ\r\nobhdkvjnz<lñs\r\nhjsdkvjbnz<vg\r\na`ñphvkljzxm´<f<kbjgvlkza<añdhblkjas+\r\nz<dkv´p\r\nz<djklñas<n´ñvbhjsdk\r\nç´hdjbñsd2.4asdfopk\r\n´pvkbvzhjxvmlñaseioñdviw2489tq24\'978945\'¡v1ewfwafawef', 'lg ', '2ebhajks´ñasmdlkazsdkfbvkjansdñlvj´paz<smdkldkndhhjdhdjnvgbvfjnfjsdzjkjszh<ksdhjnszljdhf´sdjflkasndjfhasjdhfjkasdhfhasdgfgasdghasdfsdafjksdahjkdsghdsafgsdahgsdagsdhgsdaghsdahjasdhjsdghsdghghsghssghghsghsghsghsghsghsghsghsghghsghjhjsghsghsghjsghsghsghsghsghsghghsghsghsghsghsghghsghsghsghghsghsghsghsghjjhsjhsghsghghshjsghjshjshhjsghsghsghghsghsghsghsghsghsgh', 'extractor.PNG', 2, 1, 50, '29/05/2017 02:33 am', 21),
(9, 'vb nmeba', '20002000', 'jhasdvfhjvhjv\r\nsadlkfnkajsbvj\r\nasdklfbvksbvjkl\r\najsdkjvbajsv\r\nasdijghbvkjz<v\r\nsdjbvjk<znv\r\nkijsdbvgjklnzalñ\r\nobhdkvjnz<lñs\r\nhjsdkvjbnz<vg\r\na`ñphvkljzxm´<f<kbjgvlkza<añdhblkjas+\r\nz<dkv´p\r\nz<djklñas<n´ñvbhjsdk\r\nç´hdjbñsd2.4asdfopk\r\n´pvkbvzhjxvmlñaseioñdviw2489tq24\'978945\'¡v1ewfwafawef', 'lg  nv bnv bv', '2ebhajks´ñasmdlkazsdkfbvkjansdñlvj´paz<smdkldkndhhjdhdjnvgbvfjnfjsdzjkjszh<ksdhjnszljdhf´sdjflkasndjfhasjdhfjkasdhfhasdgfgasdghasdfsdafjksdahjkdsghdsafgsdahgsdagsdhgsdaghsdahjasdhjsdghsdghghsghssghghsghsghsghsghsghsghsghsghghsghjhjsghsghsghjsghsghsghsghsghsghghsghsghsghsghsghghsghsghsghghsghsghsghsghjjhsjhsghsghghshjsghjshjshhjsghsghsghghsghsghsghsghsghsgh', 'extractor.PNG', 2, 1, 20, '29/05/2017 02:34 am', 21),
(10, 'hidro labadopra', '30000', 'jhasdvfhjvhjv\r\nsadlkfnkajsbvj\r\nasdklfbvksbvjkl\r\najsdkjvbajsv\r\nasdijghbvkjz<v\r\nsdjbvjk<znv\r\nkijsdbvgjklnzalñ\r\nobhdkvjnz<lñs\r\nhjsdkvjbnz<vg\r\na`ñphvkljzxm´<f<kbjgvlkza<añdhblkjas+\r\nz<dkv´p\r\nz<djklñas<n´ñvbhjsdk\r\nç´hdjbñsd2.4asdfopk\r\n´pvkbvzhjxvmlñaseioñdviw2489tq24\'978945\'¡v1ewfwafawef', 'samsumg', '2ebhajks´ñasmdlkazsdkfbvkjansdñlvj´paz<smdkldkndhhjdhdjnvgbvfjnfjsdzjkjszh<ksdhjnszljdhf´sdjflkasndjfhasjdhfjkasdhfhasdgfgasdghasdfsdafjksdahjkdsghdsafgsdahgsdagsdhgsdaghsdahjasdhjsdghsdghghsghssghghsghsghsghsghsghsghsghsghghsghjhjsghsghsghjsghsghsghsghsghsghghsghsghsghsghsghghsghsghsghghsghsghsghsghjjhsjhsghsghghshjsghjshjshhjsghsghsghghsghsghsghsghsghsgh', 'hidrolavadora.PNG', 1, 1, 0, '29/05/2017 02:40 am', 21),
(11, 'hidro labadopra', '30000', 'jhasdvfhjvhjv\r\nsadlkfnkajsbvj\r\nasdklfbvksbvjkl\r\najsdkjvbajsv\r\nasdijghbvkjz<v\r\nsdjbvjk<znv\r\nkijsdbvgjklnzalñ\r\nobhdkvjnz<lñs\r\nhjsdkvjbnz<vg\r\na`ñphvkljzxm´<f<kbjgvlkza<añdhblkjas+\r\nz<dkv´p\r\nz<djklñas<n´ñvbhjsdk\r\nç´hdjbñsd2.4asdfopk\r\n´pvkbvzhjxvmlñaseioñdviw2489tq24\'978945\'¡v1ewfwafawef', 'samsumg', '2ebhajks´ñasmdlkazsdkfbvkjansdñlvj´paz<smdkldkndhhjdhdjnvgbvfjnfjsdzjkjszh<ksdhjnszljdhf´sdjflkasndjfhasjdhfjkasdhfhasdgfgasdghasdfsdafjksdahjkdsghdsafgsdahgsdagsdhgsdaghsdahjasdhjsdghsdghghsghssghghsghsghsghsghsghsghsghsghghsghjhjsghsghsghjsghsghsghsghsghsghghsghsghsghsghsghghsghsghsghghsghsghsghsghjjhsjhsghsghghshjsghjshjshhjsghsghsghghsghsghsghsghsghsgh', 'hidrolavadora.PNG', 1, 1, 0, '29/05/2017 02:41 am', 21),
(12, 'horno', '200000', 'hola hola\r\nholaholav\r\nvvvholaholavvholaholaholaholaholaholaholaholaholaholaholaholaholaholaholaholaholavvvvvholaholaholavvvvholavvvholavvholaholaholaholaholaholav', 'lg', 'holavvholaholavholavholaholaholaholaholaholaholahola', 'horno empotrar.PNG', 2, 1, 0, '28/05/2017 08:57 pm', 21),
(13, 'horno', '200000', 'hola hola\r\nholaholav\r\nvvvholaholavvholaholaholaholaholaholaholaholaholaholaholaholaholaholaholaholaholavvvvvholaholaholavvvvholavvvholavvholaholaholaholaholaholav', 'lg', 'holavvholaholavholavholaholaholaholaholaholaholahola', 'horno empotrar.PNG', 2, 1, 0, '28/05/2017 08:59 pm', 21),
(14, 'horno', '200000', 'hola hola\r\nholaholav\r\nvvvholaholavvholaholaholaholaholaholaholaholaholaholaholaholaholaholaholaholaholavvvvvholaholaholavvvvholavvvholavvholaholaholaholaholaholav', 'lg', 'holavvholaholavholavholaholaholaholaholaholaholahola', 'horno empotrar.PNG', 2, 1, 0, '28/05/2017 09:04 pm', 21),
(15, 'horno', '200000', 'hola hola\r\nholaholav\r\nvvvholaholavvholaholaholaholaholaholaholaholaholaholaholaholaholaholaholaholaholavvvvvholaholaholavvvvholavvvholavvholaholaholaholaholaholav', 'lg', 'holavvholaholavholavholaholaholaholaholaholaholahola', 'horno empotrar.PNG', 2, 1, 0, '28/05/2017 09:04 pm', 21),
(16, 'horno', '200000', 'hola hola\r\nholaholav\r\nvvvholaholavvholaholaholaholaholaholaholaholaholaholaholaholaholaholaholaholaholavvvvvholaholaholavvvvholavvvholavvholaholaholaholaholaholav', 'lg', 'holavvholaholavholavholaholaholaholaholaholaholahola', 'horno empotrar.PNG', 2, 1, 0, '28/05/2017 09:05 pm', 21),
(17, 'horno', '200000', 'hola hola\r\nholaholav\r\nvvvholaholavvholaholaholaholaholaholaholaholaholaholaholaholaholaholaholaholaholavvvvvholaholaholavvvvholavvvholavvholaholaholaholaholaholav', 'lg', 'holavvholaholavholavholaholaholaholaholaholaholahola', 'horno empotrar.PNG', 2, 1, 0, '28/05/2017 09:06 pm', 21),
(18, 'horno', '200000', 'hola hola\r\nholaholav\r\nvvvholaholavvholaholaholaholaholaholaholaholaholaholaholaholaholaholaholaholaholavvvvvholaholaholavvvvholavvvholavvholaholaholaholaholaholav', 'lg', 'holavvholaholavholavholaholaholaholaholaholaholahola', 'horno empotrar.PNG', 2, 1, 0, '28/05/2017 09:08 pm', 21),
(19, 'horno', '50000', 'fafaffa\r\nfafaffafafaffa\r\nfafaffafafaffavfafaffafafaffafafaffavvvvfafaffavfafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffavfafaffavvvvvvvv', 'lg', 'fafaffafafaffavfafaffafafaffafafaffavfafaffav\r\nfafaffa\r\nfafaffa\r\nfafaffavfafaffa', 'horno empotrar.PNG', 1, 1, 0, '28/05/2017 09:24 pm', 21),
(20, 'horno', '50000', 'fafaffa\r\nfafaffafafaffa\r\nfafaffafafaffavfafaffafafaffafafaffavvvvfafaffavfafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffavfafaffavvvvvvvv', 'lg', 'fafaffafafaffavfafaffafafaffafafaffavfafaffav\r\nfafaffa\r\nfafaffa\r\nfafaffavfafaffa', 'horno empotrar.PNG', 1, 1, 0, '28/05/2017 09:25 pm', 21),
(21, 'horno', '510', 'fafaffaxhxdfhgafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffafafaffavfafaffavvvvvvvv', 'lg', 'fafaffafafaffavfafaffafafaffafafaffavfafaffav\r\nfafaffa\r\nfafafxfgbfa\r\nfafafbgfavfafaffa', 'horno empotrar.PNG', 2, 1, 0, '28/05/2017 09:25 pm', 21);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `password` varchar(500) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `edad` int(3) NOT NULL DEFAULT '18',
  `permisos` int(1) NOT NULL DEFAULT '0',
  `activo` int(1) NOT NULL DEFAULT '0',
  `keyreg` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `keypass` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `newpass` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ultima_conexion` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `img` varchar(70) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default.jpg',
  `firma` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rango` varchar(70) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'usuario',
  `fecha_registro` varchar(11) COLLATE utf8_unicode_ci NOT NULL DEFAULT '29/05/2017',
  `estadisticas` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nombre`, `email`, `password`, `edad`, `permisos`, `activo`, `keyreg`, `keypass`, `newpass`, `ultima_conexion`, `img`, `firma`, `rango`, `fecha_registro`, `estadisticas`) VALUES
(10, 'pedro', '', '12345', 56, 1, 0, '', '', '0', '0', 'default.jpg', '', 'usuario', '29/05/2017', 'a'),
(12, 'man', 'ghhgghgh|@HDF', '1234', 21, 1, 0, '', '', '0', '0', 'default.jpg', '', 'usuario', '29/05/2017', 'b'),
(14, 'sebas', 'sebas@gmail.com', 'd41d8cd98f00b204e9800998ecf842', 18, 1, 0, '', '', '0', '0', 'default.jpg', '', 'usuario', '29/05/2017', 'c'),
(18, 'toño', 'jsrodriguez4424@misena.edu.co', '65402f90ef3ceb04c9a50fe3b5aa895d', 0, 1, 0, '780dfa7f699adf123ff03f7a285d1b96', '', '0', '1496096266', 'default.jpg', '', 'usuario', '29/05/2017', 'd'),
(21, 'pato', 'juan508sebastian@gmail.com', '65402f90ef3ceb04c9a50fe3b5aa895d', 56, 2, 1, '', '', '', '1496095875', 'default.jpg', '', 'usuario', '29/05/2017', 'e'),
(22, 'julio', 'julio@gmial.com', '65402f90ef3ceb04c9a50fe3b5aa895d', 56, 0, 0, 'b240623d2724d0bfc918669096bce1e2', '', '', '0', 'default.jpg', '', 'usuario', '29/05/2017', 'f');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administrador`
--
ALTER TABLE `administrador`
  ADD PRIMARY KEY (`id_administrador`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id_categorias`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_producto`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `administrador`
--
ALTER TABLE `administrador`
  MODIFY `id_administrador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id_categorias` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id_producto` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
